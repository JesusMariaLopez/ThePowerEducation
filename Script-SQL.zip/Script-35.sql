-- Selecciona todos los actores cuyo primer nombre es 'Johnny'.

	select 
	CONCAT(A.first_name , ' ' ,A.last_name ) as "Actor"
	from actor a 
	where LOWER(a.first_name) like LOWER('Johnny')
