-- Encuentra la variabilidad de lo que costaría reemplazar las películas.

select ROUND(variance(f.replacement_cost ),2) as Variabilidad_Reemplazo
from film f 
