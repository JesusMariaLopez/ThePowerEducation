-- Encuentra el promedio de duración de las películas para cada clasificación de la tabla film y muestra la clasificación junto con el
-- promedio de duración.

select f.rating , round(avg(f.length ),2)
from film f 
group by f.rating 