-- Obtener todas las películas y mostrar los actores que han actuado en ellas, incluso si algunas películas no tienen actores asociados.

	select 
	f.title,
	concat(a.first_name, ' ', a.last_name) as "Actor"
	from film f 
	left join film_actor fa 
	on f.film_id = fa.film_id 
	left join actor a 
	on fa.actor_id = a.actor_id 
	order by f.title asc
