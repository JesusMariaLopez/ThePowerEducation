-- Encuentra el nombre y apellido de los actores que tengan ‘Allen’ en su apellido.

select CONCAT(a.first_name , ' ', a.last_name )
from actor a 
where a.last_name like ('%ALLEN%')