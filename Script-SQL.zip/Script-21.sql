-- ¿Cuál es la media de duración del alquiler de las películas?

select round(avg(f.rental_duration  ),2) as "Media Duracion Alaquiler"
from film f 
