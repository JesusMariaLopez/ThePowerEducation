-- Encuentra el promedio, la desviación estándar y varianza del total pagado.

select 
ROUND(AVG(p.amount ),2) as "Promedio",
ROUND(STDDEV(p.amount ),2) as "Desviacion",
ROUND(VARIANCE(p.amount ),2) as "Varianza"
from payment p 