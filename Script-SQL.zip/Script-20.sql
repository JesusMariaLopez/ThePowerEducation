-- Encuentra las categorías de películas que tienen un promedio de duración superior a 110 minutos y muestra el nombre de la categoría
-- junto con el promedio de duración.

select c."name"  as "Categoria", round(avg(f.length ),2) as "Promedio"
from film f 
inner join film_category fc 
on f.film_id = fc.film_id 
inner join category c 
on fc.category_id = c.category_id 
group by c."name" 
having round(avg(f.length ),2) > 110
