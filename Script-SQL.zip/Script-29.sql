-- Obtener todas las películas y, si están disponibles en el inventario, mostrar la cantidad disponible.

select 
f.title as "Pelicula",
count(i.film_id ) as "Cantidad disponible"
from film f 
left join inventory i 
on f.film_id = i.film_id 
group by f.title,i.film_id 
