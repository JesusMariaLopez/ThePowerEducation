-- Encuentra las películas con una duración superior al promedio.

select f.title as "Titulo",f.length as "Duracion" 
from film f 
where f.length >
	(
	select ROUND(avg(f2.length ),2) as "Promedio"
	from film f2 
	)