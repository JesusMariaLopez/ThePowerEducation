-- Encuentra el número de películas por categoría estrenadas en 2006.

select 
c."name" as "Categoria", count(f.film_id) as "Numero peliculas", f.release_year as "Año Estreno"
from film f 
inner join film_category fc 
on f.film_id = fc.film_id 
inner join category c 
on fc.category_id = c.category_id 
where f.release_year = 2006
group by f.release_year, c.category_id 
order by "Categoria" asc
