-- Crea una columna con el nombre y apellidos de todos los actores y actrices.

select concat(a.first_name ,' ', a.last_name ) as "Nombre y Apellidos Actores"
from actor a 
order by "Nombre y Apellidos Actores"
