-- Crea una tabla temporal llamada “peliculas_alquiladas” que almacene las películas que han sido alquiladas al menos 10 veces.

CREATE TEMPORARY TABLE peliculas_alquiladas AS
select f.title as "Titulo" , count(f.film_id) as "Numero alquiler"
from film f 
inner join inventory i 
on f.film_id = i.film_id 
inner join rental r 
on i.inventory_id = r.inventory_id 
group by f.title 
having count(f.film_id) >= 10
order by "Numero alquiler" desc

select * from peliculas_alquiladas