-- Encuentra la cantidad total de películas en cada clasificación de la tabla “film” y muestra la clasificación junto con el recuento.

select f.rating, count(f.rating)
from film f 
group by f.rating 