-- Muestra los 10 clientes con mayor valor de id.

select c.customer_id as "Id" ,concat(c.first_name , ' ', c.last_name ) as "Cliente"
from customer c 
order by c.customer_id desc
limit 10