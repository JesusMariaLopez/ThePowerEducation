-- Encuentra el nombre y apellido de los actores que han actuado en películas que se alquilaron después de que la película ‘Spartacus Cheaper’ 
-- se alquilara por primera vez. Ordena los resultados alfabéticamente por apellido.

WITH primera_fecha_alquiler AS 
(
	select r.rental_date as "Fecha alquiler primera vez"
	from film f 
	inner join inventory i 
	on f.film_id = i.film_id 
	inner join rental r 
	on i.inventory_id = r.inventory_id 
	where f.title ilike 'Spartacus Cheaper'
	order by r.rental_date asc
	limit 1 
)


select f.title  as "Titulo",a.last_name as "Apellido",concat(a.first_name  , ' ' , a.last_name) as "Actor" , r.rental_date 
from film f 
inner join film_actor fa 
on f.film_id = fa.film_id 
inner join actor a 
on fa.actor_id = a.actor_id 
inner join inventory i 
on f.film_id = i.film_id 
inner join rental r 
on i.inventory_id = r.inventory_id 
where r.rental_date >
(
	select "Fecha alquiler primera vez" from primera_fecha_alquiler
)
order by a.last_name asc

