-- ¿Cuánto dinero ha generado en total la empresa?

select sum(p.amount) as "Total Ingresos"
from payment p 