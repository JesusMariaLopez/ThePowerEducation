-- Encuentra el nombre y apellido de los actores que aparecen en la película con título ‘Egg Igby’.

select f.title as "Titulo" , concat(a.first_name, ' ' ,a.last_name) as "Actor"
from film f 
inner join film_actor fa 
on f.film_id = fa.film_id 
inner join actor a 
on fa.actor_id = a.actor_id 
where f.title ilike 'EGG IGBY'
order by "Actor" asc
