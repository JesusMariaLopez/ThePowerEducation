-- Obtén las películas cuyo idioma coincide con el idioma original.

select  f.description 
from film f 
where f.original_language_id  = f.language_id 


