-- Obtener los actores y el número de películas en las que ha actuado.

	select 
	concat(a.first_name, ' ', a.last_name) as "Actor",
	count(a.actor_id ) as "Numero peliculas con este actor"
	from film f 
	inner join film_actor fa 
	on f.film_id = fa.film_id 
	inner join actor a 
	on fa.actor_id = a.actor_id 
	group by a.actor_id 

