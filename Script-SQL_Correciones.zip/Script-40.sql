-- Selecciona las primeras 5 películas de la tabla “film”.

select f.title as "Titulo"
from film f 
limit 5