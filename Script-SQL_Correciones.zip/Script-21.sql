-- ¿Cuál es la media de duración del alquiler de las películas?

select avg(f.rental_duration  ) as "Media Duracion Alaquiler"
from film f 
