-- Obtén todas las combinaciones posibles de trabajadores con las tiendas que tenemos.

select 
concat(s.first_name ,' ' , s.last_name ) as "Trabajador", a.address as "Tienda"
from staff s 
cross join store as st
inner join address a 
on st.address_id = a.address_id 