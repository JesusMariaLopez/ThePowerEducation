-- Encuentra los nombres de los clientes que han alquilado al menos 7 películas distintas. Ordena los resultados alfabéticamente por apellido.

select 
concat(c.first_name , ' ' , c.last_name) as "Cliente", count(r.rental_id ) as "Numero peliculas"
from film f 
inner join inventory i 
on f.film_id = i.film_id 
inner join rental r 
on i.inventory_id = r.inventory_id 
inner join customer c 
on r.customer_id = c.customer_id 
group by r.customer_id , c.first_name, c.last_name
having count(r.rental_id ) > 7
order by c.last_name asc
