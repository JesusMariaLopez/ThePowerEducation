-- Encuentra el ID del actor más bajo y más alto en la tabla actor.

	select 
	min(a.actor_id ) as "Id más bajo",
	max(a.actor_id)  as "Id más alto"
	from actor a 
