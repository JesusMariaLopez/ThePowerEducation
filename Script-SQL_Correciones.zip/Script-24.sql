-- Encuentra las películas con una duración superior al promedio.

select f.title as "Titulo",f.length as "Duracion" 
from film f 
where f.length >
	(
	select avg(f2.length ) as "Promedio"
	from film f2 
	)