-- Selecciona todos los nombres de las películas únicos.

select distinct(f.title ) as "Titulo"
from film f 
order by f.title asc
