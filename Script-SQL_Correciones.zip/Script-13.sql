-- Encuentra el promedio de duración de las películas para cada clasificación de la tabla film y muestra la clasificación junto con el
-- promedio de duración.

select f.rating , avg(f.length )
from film f 
group by f.rating 