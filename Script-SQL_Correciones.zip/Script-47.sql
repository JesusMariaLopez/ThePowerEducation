-- Selecciona el nombre de los actores y la cantidad de películas en las que han participado.

select 
concat(a.first_name, ' ' , a.last_name) as "Actor",
count(a.actor_id ) as "Numero peliculas"
from actor a 
inner join film_actor fa 
on a.actor_id  = fa.actor_id 
group by a.actor_id 
order by "Numero peliculas" desc
