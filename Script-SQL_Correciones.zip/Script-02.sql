--Muestra los nombres de todas las películas con una clasificación por edades de ‘R’.

select f.title as "Titulo"
from film f 
where f.rating = 'R'