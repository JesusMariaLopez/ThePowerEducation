-- Encuentra la cantidad total de películas alquiladas por cada cliente y muestra el ID del cliente, su nombre y apellido junto con la cantidad de
-- películas alquiladas.

select 
r.customer_id as "ID cliente", concat(c.first_name , ' ' , c.last_name ) as "Cliente", count(r.rental_id ) as "Numero Peliculas"
from film f 
inner join inventory i 
on f.film_id = i.film_id 
inner join rental r 
on i.inventory_id = r.inventory_id 
inner join customer c 
on r.customer_id = c.customer_id 
group by r.customer_id ,"Cliente" 
order by "Cliente" asc
