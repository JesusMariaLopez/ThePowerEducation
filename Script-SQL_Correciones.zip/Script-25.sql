-- Averigua el número de alquileres registrados por mes.

select to_char(r.rental_date, 'MM') as "Mes", COUNT(r.rental_date) as "Nº Alquileres"
from rental r 
group by to_char(r.rental_date, 'MM')
order by "Nº Alquileres" desc
