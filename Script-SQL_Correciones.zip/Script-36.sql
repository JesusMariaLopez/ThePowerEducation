-- Renombra la columna “first_name” como Nombre y “last_name” como Apellido.

	select 
	a.first_name as "Nombre",
	a.last_name  as "Apellido"
	from actor a 
