-- Encuentra el título de todas las películas que son ‘PG-13’ o tienen una duración mayor a 3 horas en la tabla film.

select f.title ,f.rating ,f.length 
from film f 
where 
(
f.rating = 'PG-13'
or
f.length > 180
)