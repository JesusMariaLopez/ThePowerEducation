-- Encuentra los 5 clientes que más dinero se hayan gastado con nosotros.

	select 
	r.customer_id as "Cliente",
	concat(c.first_name, ' ' , c.last_name),
	sum(p.amount ) as "Gasto por cliente"
	from  film f 
	inner join inventory i 
	on f.film_id = i.film_id 
	inner join rental r 
	on i.inventory_id = r.inventory_id 
	inner join customer c 
	on r.customer_id = c.customer_id 
	inner join payment p 
	on r.rental_id  = p.rental_id 
	group by r.customer_id , concat(c.first_name, ' ' , c.last_name)
	order by "Gasto por cliente" desc
	limit 5
