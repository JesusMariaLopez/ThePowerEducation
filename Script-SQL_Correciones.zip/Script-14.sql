-- Encuentra el título de todas las películas que tengan una duración mayor a 180 minutos.

select f.title as "Titulo ",f.length as "Duracion"
from film f 
where f.length > 180