-- Obtener todas las películas que tenemos y todos los registros de alquiler.

	select 
	f.title as "Titulo",
	r.rental_date as "Fecha Alquiler"
	from  film f 
	inner join inventory i 
	on f.film_id = i.film_id 
	inner join rental r 
	on i.inventory_id = r.inventory_id 
	order by "Titulo" asc, "Fecha Alquiler" asc