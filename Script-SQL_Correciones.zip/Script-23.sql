-- Números de alquiler por día, ordenados por cantidad de alquiler de forma descendente.

select to_char(r.rental_date, 'YYYY-MM-DD') as "Fecha", COUNT(r.rental_date) as "Nº Alquileres"
from rental r 
group by to_char(r.rental_date, 'YYYY-MM-DD')
order by "Nº Alquileres" desc

