-- Obtener todos los actores y mostrar las películas en las que han actuado, incluso si algunos actores no han actuado en ninguna película.

	select 
	concat(a.first_name, ' ', a.last_name) as "Actor",
	f.title as "Titulo"
	from actor a 
	left join film_actor fa 
	on a.actor_id = fa.actor_id 
	inner join film f 
	on fa.film_id = f.film_id 
	order by "Actor" asc, "Titulo" asc
