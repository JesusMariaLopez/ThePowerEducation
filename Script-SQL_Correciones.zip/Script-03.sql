
--Encuentra los nombres de los actores que tengan un “actor_id” entre 30 y 40.

select CONCAT(a.first_name, ' ' ,a.last_name)
from actor a 
where a.actor_id  between 30 and 40