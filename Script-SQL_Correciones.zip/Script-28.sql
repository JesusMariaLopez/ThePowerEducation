-- Muestra el id de los actores que hayan participado en más de 40 películas.

WITH numero_peliculas_actor AS 
(
	select 
	a.actor_id as "actor_id"
	from film f 
	inner join film_actor fa 
	on f.film_id = fa.film_id 
	inner join actor a 
	on fa.actor_id = a.actor_id 
	group by a.actor_id 
	having count(a.actor_id ) > 40
)

select "actor_id" from numero_peliculas_actor
