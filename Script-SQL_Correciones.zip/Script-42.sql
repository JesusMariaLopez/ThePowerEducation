-- Encuentra todos los alquileres y los nombres de los clientes que los realizaron.

select 
concat(c.first_name ,' ' ,c.last_name) as "Cliente",
r.rental_date as "Fecha Alquiler"
from rental r 
inner join customer c 
on r.customer_id = c.customer_id 
order by "Cliente" asc, "Fecha Alquiler" asc