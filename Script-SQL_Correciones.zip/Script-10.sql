-- Encuentra la mayor y menor duración de una película de nuestra BBDD.

select MAX(f.length ) as "Pelicula con mayor duracion", MIN(f.length ) as "Pelicula con menor duracion"
from film f 
