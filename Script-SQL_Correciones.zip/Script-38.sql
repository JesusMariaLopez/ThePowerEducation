-- Cuenta cuántos actores hay en la tabla “actor”.

	select 
	count(a.actor_id ) as "Numero de actores"
	from actor a 
