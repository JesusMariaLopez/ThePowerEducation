-- Crea una tabla temporal llamada “cliente_rentas_temporal” para almacenar el total de alquileres por cliente.

CREATE TEMPORARY TABLE cliente_rentas_temporal AS
select concat(c.first_name, ' ' , c.last_name) as "Cliente" , sum(f.rental_rate) as "Total alquiler"
from film f 
inner join inventory i 
on f.film_id = i.film_id 
inner join rental r 
on i.inventory_id = r.inventory_id 
inner join customer c 
on r.customer_id = c.customer_id 
group by c.customer_id 
order by "Total alquiler" desc

select * from cliente_rentas_temporal