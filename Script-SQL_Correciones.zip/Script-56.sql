-- Encuentra el nombre y apellido de los actores que no han actuado en ninguna película de la categoría ‘Music’.

WITH peliculas_categorias AS 
(
	select f.title as "Titulo"
	from film f 
	inner join inventory i 
	on f.film_id = i.film_id 
	inner join film_category fc 
	on f.film_id = fc.film_id 
	inner join category c 
	on fc.category_id = c.category_id 
	where c."name" ilike 'Music'
)


select f.title as "Titulo",a.last_name as "Apellido",concat(a.first_name  , ' ' , a.last_name) as "Actor"  
from film f 
inner join film_actor fa 
on f.film_id = fa.film_id 
inner join actor a 
on fa.actor_id = a.actor_id 
where f.title not in
(
	select "Titulo" from peliculas_categorias
)
order by a.last_name asc

