-- Encuentra todos los actores que no han participado en películas.

WITH numero_peliculas_actor AS 
(
	select a.actor_id as "Id_Actor",
	count(a.actor_id ) as "Numero peliculas"
	from actor a 
	inner join film_actor fa 
	on a.actor_id  = fa.actor_id 
	group by a.actor_id 
)

select concat(a.first_name, ' ' , a.last_name) as "Actor"
from actor a 
where a.actor_id not in 
(
SELECT "Id_Actor" FROM numero_peliculas_actor
)

