-- Encuentra los nombres de los actores que han actuado en al menos una película que pertenece a la categoría ‘Sci-Fi’. Ordena los resultados
-- alfabéticamente por apellido.

select a.last_name as "Apellido",concat(a.first_name  , ' ' , a.last_name) as "Actor" , f.title  as "Titulo", c."name"  as "Categoria"
from film f 
inner join film_actor fa 
on f.film_id = fa.film_id 
inner join actor a 
on fa.actor_id = a.actor_id 
inner join film_category fc 
on f.film_id = fc.film_id 
inner join category c 
on fc.category_id = c.category_id 
where c."name" = 'Sci-Fi'
order by a.last_name asc

