-- Encuentra los nombres de las películas que tienen la misma duración que la película con el título ‘Dancing Fever’. Ordena los resultados
-- alfabéticamente por título de película.

select f.title as "Titulo"
from film f 
where f.length =
(
select f1.length 
from film f1 
where f1.title ilike 'Dancing Fever'
)
order by "Titulo" ASC
