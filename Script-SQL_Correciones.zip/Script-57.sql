-- Encuentra el título de todas las películas que fueron alquiladas por más de 8 días.

WITH peliculas_alquiladas_8 AS 
(
	select f.title as "Titulo", r.rental_date::DATE as "Fecha Alquiler" , r.return_date::DATE as "Fecha Devolucion", (r.return_date::DATE - r.rental_date::DATE) as "Dias"
	from film f 
	inner join inventory i 
	on f.film_id = i.film_id 
	inner join rental r 
	on i.inventory_id = r.inventory_id 
	order by "Titulo" asc
)

select distinct "Titulo" from peliculas_alquiladas_8 where "Dias" > 8
order by "Titulo" asc

/*
Se podria realizar este script solo con las primeras entencias, se ha dejado de esta forma para darle más versatilidadalter 
*/