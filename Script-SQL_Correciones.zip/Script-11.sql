-- Encuentra lo que costó el antepenúltimo alquiler ordenado por día.

select p.payment_date as "Fecha Alquiler" ,p.amount as "Precio Costo"
from payment p 
order by p.payment_date desc
limit 1
offset 0
