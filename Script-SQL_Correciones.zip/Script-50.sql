-- Calcula la duración total de las películas en la categoría 'Action'.

select 
sum(f.length ) as "Duracion Total peliculas",
c."name" as "Categoria"
from film f 
inner join film_category fc 
on f.film_id = fc.film_id 
inner join category c 
on fc.category_id = c.category_id 
group by c."name"
having c."name" = 'Action'