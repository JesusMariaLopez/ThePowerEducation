-- ¿Qué películas se alquilan por encima del precio medio?

WITH precio_promedio AS (
    SELECT AVG(f.rental_rate ) AS "Precio alquiler"
    FROM film f 
)

select 
f1.title as "Titulo",
f1.rental_rate as "Precio alquiler",
(SELECT "Precio alquiler" FROM precio_promedio) as "Precio Medio"
from film f1 
where f1.rental_rate >
(SELECT "Precio alquiler" FROM precio_promedio);

