-- Crea una vista llamada “actor_num_peliculas” que muestre los nombres de los actores y el número de películas en las que han participado.

create view “actor_num_peliculas” as
select 
concat(a.first_name, ' ' , a.last_name) as "Actor",
count(a.actor_id ) as "Numero peliculas"
from actor a 
inner join film_actor fa 
on a.actor_id  = fa.actor_id 
group by a.actor_id 
order by "Numero peliculas" desc
