-- Calcula el número total de alquileres realizados por cada cliente.

select 
concat(c.first_name, ' ' ,c.last_name),
count(r.customer_id  ) as "Numero Total alquileres"
from customer c 
inner join rental r 
on c.customer_id = r.customer_id 
group by r.customer_id , concat(c.first_name, ' ' ,c.last_name)
order by "Numero Total alquileres" desc