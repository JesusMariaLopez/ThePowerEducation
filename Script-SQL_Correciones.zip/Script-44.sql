-- Realiza un CROSS JOIN entre las tablas film y category. ¿Aporta valor esta consulta? ¿Por qué? Deja después de la consulta la contestación.

select f.title ,c."name" 
from film f 
inner join film_category fc 
on f.film_id = fc.film_id 
cross join category c 

/*
No aporta ningun valor refencial, ya que mezclamos una pelicula con todas las categorias posibles
y este conjunto de datos se vuelve enorme
*/
