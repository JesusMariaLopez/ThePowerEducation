-- Encuentra el título de las películas en la tabla “film” que no sean ni ‘NC-17’ ni ‘G’ en cuanto a su clasificación.

select f.title ,f.rating 
from film f 
where f.rating not in ('NC-17','G')