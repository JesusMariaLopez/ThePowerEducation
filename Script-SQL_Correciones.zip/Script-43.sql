-- Muestra todos los clientes y sus alquileres si existen, incluyendo aquellos que no tienen alquileres.

select 
concat(c.first_name ,' ' ,c.last_name) as "Cliente",
r.rental_date as "Fecha Alquiler"
from customer c 
left join rental r
on r.customer_id = c.customer_id 
order by "Cliente" asc, "Fecha Alquiler" asc