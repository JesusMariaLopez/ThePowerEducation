-- Encuentra la variabilidad de lo que costaría reemplazar las películas.

select variance(f.replacement_cost ) as Variabilidad_Reemplazo
from film f 
