-- Selecciona todos los actores y ordénalos por apellido en orden ascendente.

	select 
	concat(a.first_name , ' ' , a.last_name )
	from actor a 
	order by a.last_name asc 