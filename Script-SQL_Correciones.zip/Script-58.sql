-- Encuentra el título de todas las películas que son de la misma categoría que ‘Animation’.

select f.title as "Titulo", c."name" as "Categoria"
from film f 
inner join film_category fc 
on f.film_id = fc.film_id 
inner join category c 
on fc.category_id  = c.category_id 
where C."name" ilike 'Animation'
order by "Titulo" ASC
