-- Ordena las películas por duración de forma ascendente.

select f.title 
from film f 
order by f.length  asc

