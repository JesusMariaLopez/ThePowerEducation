-- Encuentra el título de las películas que son comedias y tienen una duración mayor a 180 minutos en la tabla “film”.

select f.title as "Titulo" ,c."name"  as "Categoria"
from film f 
inner join film_category fc 
on f.film_id = fc.film_id 
inner join category c 
on fc.category_id = c.category_id 
where f.length > 180
and c."name" = 'Comedy'