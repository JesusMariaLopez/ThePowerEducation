-- Encuentra el título de las películas que han sido alquiladas por el cliente con el nombre ‘Tammy Sanders’ y que aún no se han devuelto. Ordena
-- los resultados alfabéticamente por título de película.

select concat(c.first_name , ' ' , c.last_name) as "Cliente" , f.title  as "Titulo", r.return_date as "Fecha Devolucion"
from film f 
inner join inventory i 
on f.film_id = i.film_id 
inner join rental r 
on i.inventory_id = r.inventory_id 
inner join customer c 
on r.customer_id = c.customer_id 
where concat(c.first_name , ' ' , c.last_name) ilike 'Tammy Sanders'
and r.return_date  is null
order by "Titulo" asc

