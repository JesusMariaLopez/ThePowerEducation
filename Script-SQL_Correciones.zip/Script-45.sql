-- Encuentra los actores que han participado en películas de la categoría 'Action'.

select f.title ,c."name" as "Categoria" , concat(a.first_name, ' ' , a.last_name) as "Actor"
from film f 
inner join film_category fc 
on f.film_id = fc.film_id 
inner join category c
on fc.category_id = c.category_id 
inner join film_actor fa 
on f.film_id = fa.film_id 
inner join actor a 
on fa.actor_id  = a.actor_id 
where c."name" = 'Action'

