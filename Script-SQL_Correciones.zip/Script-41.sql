-- Agrupa los actores por su nombre y cuenta cuántos actores tienen el mismo nombre. ¿Cuál es el nombre más repetido?

select 
a.first_name as "Nombre actor",
count(a.first_name) as "Numero actores mismo nombre"
from actor a
group by a.first_name
order by "Numero actores mismo nombre" desc