-- Encuentra el promedio, la desviación estándar y varianza del total pagado.

select 
AVG(p.amount ) as "Promedio",
STDDEV(p.amount ) as "Desviacion",
VARIANCE(p.amount ) as "Varianza"
from payment p 